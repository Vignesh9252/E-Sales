export enum CategoryType {
    "Books", "Food", "Clothes", "Drink"
}
