package me.zhulin.shopapi.service.impl;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created By Zhu Lin on 1/4/2019.
 */
public class OrderServiceImplTest {

    @Test
    public void finish() {
    }

    @Test
    public void cancel() {
    }
}
